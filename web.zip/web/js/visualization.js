// 可视化模块 - 图表和图结构可视化

// 渲染训练曲线图表
function renderCharts(losses, accs) {
    if (!window.Plotly) return;
    
    // 损失曲线
    Plotly.newPlot('loss-chart', [{
        y: losses, 
        type: 'scatter', 
        name: 'Loss', 
        line: { color: '#ef4444' }
    }], {
        margin: { t: 10, b: 30, l: 40, r: 10 }, 
        yaxis: { title: 'Loss' }
    });
    
    // 准确率曲线
    Plotly.newPlot('accuracy-chart', [{
        y: accs, 
        type: 'scatter', 
        name: 'Acc', 
        line: { color: '#10b981' }
    }], {
        margin: { t: 10, b: 30, l: 40, r: 10 }, 
        yaxis: { title: 'Accuracy', range: [0, 1] }
    });
}

// 渲染图结构可视化
function renderGraph(finalAcc, correctFlags, neighborsInfo) {
    var container = document.getElementById('graph-visualization');
    if (!container || !window.d3) return;
    
    container.innerHTML = '';
    var width = container.clientWidth || 400;
    var height = 220;
    var svg = d3.select(container).append('svg').attr('width', width).attr('height', height);
    
    // 根据是否有邻居信息判断是 GraphSAGE 还是 GCN
    var isGraphSAGE = neighborsInfo && Object.keys(neighborsInfo).length > 0;
    
    var nodes, links;
    if (isGraphSAGE) {
        // GraphSAGE: 10 节点复杂图
        nodes = d3.range(10).map(function(i) { 
            return { 
                id: i, 
                label: ['类别A', '类别A', '类别A', '类别B', '类别B', '类别B', 
                       '类别C', '类别C', '类别C', '类别C'][i] 
            }; 
        });
        links = [
            {source: 0, target: 1}, {source: 0, target: 3}, {source: 1, target: 2}, 
            {source: 1, target: 4}, {source: 2, target: 5}, {source: 3, target: 4}, 
            {source: 3, target: 6}, {source: 4, target: 5}, {source: 4, target: 7}, 
            {source: 5, target: 8}, {source: 6, target: 7}, {source: 6, target: 9},
            {source: 7, target: 8}, {source: 8, target: 9}
        ];
    } else {
        // GCN: 7 节点链式图
        nodes = d3.range(7).map(function(i) { 
            return { 
                id: i, 
                label: ['AI', 'AI', 'CV', 'CV', 'NLP', 'NLP', 'NLP'][i] 
            }; 
        });
        links = [
            {source: 0, target: 1}, {source: 1, target: 2}, {source: 2, target: 3}, 
            {source: 3, target: 4}, {source: 4, target: 5}, {source: 5, target: 6}
        ];
    }
    
    // 依据传入标记或最终准确率模拟预测正确与否
    if (Array.isArray(correctFlags) && correctFlags.length) {
        nodes.forEach(function(n, idx) { n.correct = !!correctFlags[idx]; });
    } else {
        var correctCount = Math.round(finalAcc * nodes.length);
        nodes.forEach(function(n, idx) { n.correct = idx < correctCount; });
    }
    
    var color = function(n) { return n.correct ? '#67C23A' : '#F56C6C'; };

    var simulation = d3.forceSimulation(nodes)
        .force('link', d3.forceLink(links).id(function(d) { return d.id; }).distance(50))
        .force('charge', d3.forceManyBody().strength(-150))
        .force('center', d3.forceCenter(width / 2, height / 2));

    var link = svg.append('g').selectAll('line').data(links).enter().append('line')
        .attr('stroke', '#cbd5e1').attr('stroke-width', 1.5);

    var node = svg.append('g').selectAll('circle').data(nodes).enter().append('circle')
        .attr('r', isGraphSAGE ? 8 : 10)
        .attr('fill', function(d) { return color(d); })
        .attr('class', 'graph-node')
        .call(d3.drag()
            .on('start', function(event, d) { 
                if (!event.active) simulation.alphaTarget(0.3).restart(); 
                d.fx = d.x; d.fy = d.y; 
            })
            .on('drag', function(event, d) { 
                d.fx = event.x; d.fy = event.y; 
            })
            .on('end', function(event, d) { 
                if (!event.active) simulation.alphaTarget(0); 
                d.fx = null; d.fy = null; 
            })
        );
    
    // 添加节点标签
    var labels = svg.append('g').selectAll('text').data(nodes).enter().append('text')
        .text(function(d) { return d.id; })
        .attr('text-anchor', 'middle')
        .attr('dy', '.35em')
        .attr('font-size', '10px')
        .attr('fill', 'white')
        .attr('font-weight', 'bold');
    
    // 更新提示信息
    node.append('title').text(function(d) { 
        var base = '节点 ' + d.id + '\n预测: ' + (d.correct ? '正确' : '错误');
        if (isGraphSAGE && neighborsInfo && neighborsInfo[d.id]) {
            base += '\n采样邻居: [' + neighborsInfo[d.id].join(',') + ']';
        }
        return base;
    });

    simulation.on('tick', function() {
        link.attr('x1', function(d) { return d.source.x; })
            .attr('y1', function(d) { return d.source.y; })
            .attr('x2', function(d) { return d.target.x; })
            .attr('y2', function(d) { return d.target.y; });
        node.attr('cx', function(d) { return d.x; }).attr('cy', function(d) { return d.y; });
        labels.attr('x', function(d) { return d.x; }).attr('y', function(d) { return d.y; });
    });
}

// 创建交互式图演示（用于教程页面）
function createGraphDemo(containerId) {
    var container = document.getElementById(containerId);
    if (!container || !window.d3) return;
    
    container.innerHTML = '';
    var width = container.clientWidth || 300;
    var height = 200;
    var svg = d3.select(container).append('svg').attr('width', width).attr('height', height);
    
    var nodes = [
        {id: 0, name: '小明', type: '学生'},
        {id: 1, name: '小红', type: '设计师'},
        {id: 2, name: '小刚', type: '工程师'},
        {id: 3, name: '小丽', type: '教师'},
        {id: 4, name: '小强', type: '医生'}
    ];
    
    var links = [
        {source: 0, target: 1, relation: '同学'},
        {source: 1, target: 2, relation: '同事'},
        {source: 2, target: 3, relation: '朋友'},
        {source: 3, target: 4, relation: '邻居'},
        {source: 0, target: 4, relation: '朋友'}
    ];
    
    var simulation = d3.forceSimulation(nodes)
        .force('link', d3.forceLink(links).id(function(d) { return d.id; }))
        .force('charge', d3.forceManyBody().strength(-300))
        .force('center', d3.forceCenter(width / 2, height / 2));

    var link = svg.append('g').selectAll('line').data(links).enter().append('line')
        .attr('stroke', '#999').attr('stroke-width', 2);

    var node = svg.append('g').selectAll('circle').data(nodes).enter().append('circle')
        .attr('r', 15)
        .attr('fill', function(d, i) { return d3.schemeCategory10[i]; })
        .style('cursor', 'pointer')
        .on('click', function(event, d) {
            alert('节点信息：\n姓名：' + d.name + '\n职业：' + d.type);
        });
    
    var labels = svg.append('g').selectAll('text').data(nodes).enter().append('text')
        .text(function(d) { return d.name; })
        .attr('text-anchor', 'middle')
        .attr('dy', '.35em')
        .attr('font-size', '10px')
        .attr('fill', 'white')
        .attr('font-weight', 'bold');

    simulation.on('tick', function() {
        link.attr('x1', function(d) { return d.source.x; })
            .attr('y1', function(d) { return d.source.y; })
            .attr('x2', function(d) { return d.target.x; })
            .attr('y2', function(d) { return d.target.y; });
        node.attr('cx', function(d) { return d.x; }).attr('cy', function(d) { return d.y; });
        labels.attr('x', function(d) { return d.x; }).attr('y', function(d) { return d.y; });
    });
}

// 从Pyodide提取结果
async function extractPyResults() {
    try {
        var jsonStr = await practiceState.pyodide.runPythonAsync(`
import json
out = {}
try:
    out['losses'] = list(losses)
    out['accuracies'] = list(accuracies)
except Exception as e:
    out['losses'] = [1.0,0.8,0.6,0.5]
    out['accuracies'] = [0.3,0.5,0.7,0.8]
try:
    import torch
    model.eval()
    with torch.no_grad():
        if hasattr(model, 'gat1'):  # GAT模型
            o, _, attn = model(features, adj_matrix)
            out['attention_weights'] = attn.tolist()
        elif hasattr(model, 'sage1'):  # GraphSAGE模型
            o = model(features, adj_matrix)
            # 提取邻居采样信息
            try:
                neighbors_info = {}
                for i in range(min(5, features.size(0))):
                    neighbors = sample_neighbors(adj_matrix, i, 3)
                    neighbors_info[str(i)] = neighbors.tolist()
                out['neighbors_sampled'] = neighbors_info
            except Exception as e:
                pass
        else:  # GCN模型
            o = model(features, adj_matrix)
        _, p = o.max(dim=1)
    lbl = list(map(int, labels.tolist()))
    pred = list(map(int, p.tolist()))
    pred_correct = [1 if pred[i]==lbl[i] else 0 for i in range(len(lbl))]
    out['pred_correct'] = pred_correct
except Exception as e:
    out['pred_correct'] = [1,1,0,1,0,1,1]
json.dumps(out)`);
        return JSON.parse(jsonStr);
    } catch (e) {
        return { 
            losses: [1.0, 0.8, 0.6, 0.5], 
            accuracies: [0.3, 0.5, 0.7, 0.8], 
            pred_correct: [1, 1, 0, 1, 0, 1, 1] 
        };
    }
}

// 导出函数
window.renderCharts = renderCharts;
window.renderGraph = renderGraph;
window.createGraphDemo = createGraphDemo;
window.extractPyResults = extractPyResults;