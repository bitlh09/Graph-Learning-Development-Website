// 图学习网站主要JavaScript功能

// 全局状态管理
var practiceState = {
    learningRate: 0.01,
    hiddenDim: 16,
    epochs: 200,
    cm: null,
    savedCodeKey: 'graphlearn_gcn_code_v1',
    execMode: 'simulate',
    pyodide: null,
    pyodideReady: false
};

// 页面导航功能
function showSection(id) {
    document.querySelectorAll('.section').forEach(function(s) {
        s.classList.remove('active');
        s.style.display = 'none';
    });
    var el = document.getElementById(id + '-section');
    if (el) {
        el.classList.add('active');
        el.style.display = 'block';
    }
}

// 教程页面切换
function showTutorial(id) {
    document.querySelectorAll('.tutorial-content').forEach(function(s) {
        s.classList.remove('active');
        s.style.display = 'none';
    });
    var el = document.getElementById(id);
    if (el) {
        el.classList.add('active');
        el.style.display = 'block';
    }
}

// 社区页面切换
function showCommunitySection(id) {
    var sections = ['discussions', 'projects', 'pitfalls', 'challenges', 'resources'];
    sections.forEach(function(s) {
        var el = document.getElementById(s);
        if (el) el.style.display = (s === id) ? 'block' : 'none';
    });
}

// 在线实践环境管理
function loadPracticeEnvironment(key) {
    var placeholder = document.getElementById('env-placeholder');
    if (placeholder) placeholder.style.display = 'none';
    
    document.querySelectorAll('.practice-env').forEach(function(s) {
        s.classList.add('hidden');
    });
    
    if (key === 'gcn-classification') {
        var env = document.getElementById('gcn-classification-env');
        if (env) env.classList.remove('hidden');
        initCodeEditor();
        updateLearningRate(practiceState.learningRate);
        updateHiddenDim(practiceState.hiddenDim);
        updateEpochs(practiceState.epochs);
    } else if (key === 'graphsage-sampling') {
        loadGraphSAGEEnvironment();
    } else {
        alert('该环境即将上线，敬请期待');
    }
}

function loadGraphSAGEEnvironment() {
    var env = document.getElementById('gcn-classification-env');
    if (env) env.classList.remove('hidden');
    
    var graphsageCode = `# GraphSAGE 示例代码
import torch
import torch.nn as nn
import torch.nn.functional as F

class GraphSAGE(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GraphSAGE, self).__init__()
        self.sage1 = nn.Linear(input_dim, hidden_dim)
        self.sage2 = nn.Linear(hidden_dim, output_dim)
    
    def forward(self, x, adj):
        # GraphSAGE层实现
        x = F.relu(self.sage1(x))
        x = self.sage2(x)
        return F.log_softmax(x, dim=1)

print("GraphSAGE模型已加载")`;
    
    initCodeEditor();
    if (practiceState.cm) {
        practiceState.cm.setValue(graphsageCode);
    }
    var title = document.querySelector('#gcn-classification-env h2');
    if (title) title.textContent = 'GraphSAGE 邻居采样实践';
}

// 代码编辑器初始化
function initCodeEditor() {
    if (practiceState.cm || !window.CodeMirror) return;
    var textarea = document.getElementById('code-editor');
    if (!textarea) return;
    
    practiceState.cm = CodeMirror.fromTextArea(textarea, {
        mode: 'python',
        theme: 'monokai',
        lineNumbers: true,
        viewportMargin: Infinity
    });
    
    try {
        var saved = localStorage.getItem(practiceState.savedCodeKey);
        if (saved) practiceState.cm.setValue(saved);
    } catch (e) {}
    
    initPyodideOnce();
}

// Pyodide初始化
async function initPyodideOnce() {
    if (practiceState.pyodide || !window.loadPyodide) return;
    var consoleEl = document.getElementById('console-output');
    try {
        if (consoleEl) consoleEl.textContent = '正在加载 Pyodide (首次较慢)...';
        practiceState.pyodide = await loadPyodide({ 
            indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.24.1/full/' 
        });
        practiceState.pyodideReady = true;
        if (consoleEl) consoleEl.textContent = 'Pyodide 加载完成，可切换为 Pyodide 执行模式';
    } catch (e) {
        practiceState.pyodideReady = false;
        if (consoleEl) consoleEl.textContent = 'Pyodide 加载失败：' + e;
    }
}

// 参数调整功能
function updateLearningRate(v) {
    var f = parseFloat(v);
    if (!isNaN(f)) practiceState.learningRate = f;
    var el = document.getElementById('lr-value');
    if (el) el.textContent = String(practiceState.learningRate);
}

function updateHiddenDim(v) {
    var i = parseInt(v);
    if (!isNaN(i)) practiceState.hiddenDim = i;
    var el = document.getElementById('hidden-value');
    if (el) el.textContent = String(practiceState.hiddenDim);
}

function updateEpochs(v) {
    var i = parseInt(v);
    if (!isNaN(i)) practiceState.epochs = i;
    var el = document.getElementById('epochs-value');
    if (el) el.textContent = String(practiceState.epochs);
}

// 代码运行功能
async function runCode() {
    var consoleEl = document.getElementById('console-output');
    if (consoleEl) consoleEl.textContent = '';

    if (practiceState.execMode === 'pyodide') {
        await runCodeWithPyodide();
        return;
    }

    // 前端模拟模式
    var epochs = Math.max(50, practiceState.epochs);
    var lr = practiceState.learningRate;
    var cap = Math.min(0.9, 0.5 + Math.log10(1 + lr * 100) + (practiceState.hiddenDim - 16) / 200);
    var losses = [], accs = [];
    var loss0 = 1.2 - Math.min(0.6, Math.log10(1 + lr * 100));
    
    for (var t = 0; t < epochs; t++) {
        var progress = t / (epochs - 1);
        var loss = loss0 * Math.pow(0.85 + (0.05 * (16 / practiceState.hiddenDim)), progress * 5);
        var acc = Math.min(cap, (0.2 + 0.8 * progress) * cap);
        losses.push(parseFloat(loss.toFixed(4)));
        accs.push(parseFloat(acc.toFixed(4)));
        
        if (consoleEl && (t % Math.max(1, Math.floor(epochs / 4)) === 0)) {
            consoleEl.textContent += 'Epoch ' + t + ': Loss=' + losses[t].toFixed(4) + ', Acc=' + accs[t].toFixed(4) + '\n';
        }
    }
    
    if (consoleEl) {
        consoleEl.textContent += '训练完成\n最终准确率: ' + accs[accs.length - 1].toFixed(4);
    }

    renderCharts(losses, accs);
    renderGraph(accs[accs.length - 1]);
}

async function runCodeWithPyodide() {
    if (!practiceState.pyodideReady) {
        var consoleEl = document.getElementById('console-output');
        if (consoleEl) consoleEl.textContent = 'Pyodide 正在加载或不可用，请稍候或切换到前端模拟模式。';
        return;
    }
    
    var code = practiceState.cm ? practiceState.cm.getValue() : 
               (document.getElementById('code-editor') || {}).value || '';
    
    try {
        practiceState.pyodide.runPython(`
import sys
from js import console
class _C:
  def write(self,s):
    if s: console.log(s)
  def flush(self):
    pass
sys.stdout=_C()
sys.stderr=_C()`);
        
        await practiceState.pyodide.runPythonAsync(code);
        var result = await extractPyResults();
        var consoleEl = document.getElementById('console-output');
        if (consoleEl) consoleEl.textContent = '执行完成（Pyodide）。';
        
        renderCharts(result.losses || [1, 0.8], result.accuracies || [0.3, 0.7]);
        renderGraph((result.accuracies || []).slice(-1)[0] || 0.8, 
                   result.pred_correct || [], result.neighbors_sampled || {});
    } catch (e) {
        var consoleEl = document.getElementById('console-output');
        if (consoleEl) consoleEl.textContent = '执行失败（Pyodide）：' + e;
        renderCharts([1.0, 0.8, 0.6, 0.5, 0.45, 0.4], [0.2, 0.35, 0.5, 0.62, 0.73, 0.8]);
        renderGraph(0.8);
    }
}

// 其他工具函数
function resetCode() {
    var consoleEl = document.getElementById('console-output');
    if (consoleEl) consoleEl.textContent = '点击"运行代码"查看结果...';
    
    if (window.Plotly) {
        try { Plotly.purge('loss-chart'); } catch(e) {}
        try { Plotly.purge('accuracy-chart'); } catch(e) {}
    }
    
    var gv = document.getElementById('graph-visualization');
    if (gv) gv.innerHTML = '<div class="text-center"><p>图结构可视化</p><p class="text-sm">运行代码后显示节点分类结果</p></div>';
}

function saveCode() {
    if (practiceState.cm) {
        try {
            localStorage.setItem(practiceState.savedCodeKey, practiceState.cm.getValue());
            alert('已保存到本地浏览器');
        } catch(e) { 
            alert('保存失败：浏览器不支持或存储空间不足'); 
        }
    }
}

// 页面加载完成后的初始化
document.addEventListener('DOMContentLoaded', function() {
    renderAuthState();
    showCommunitySection('discussions');
    showSection('home'); // 默认显示首页
});

// 导出主要函数到全局作用域
window.showSection = showSection;
window.showTutorial = showTutorial;
window.showCommunitySection = showCommunitySection;
window.loadPracticeEnvironment = loadPracticeEnvironment;
window.updateLearningRate = updateLearningRate;
window.updateHiddenDim = updateHiddenDim;
window.updateEpochs = updateEpochs;
window.runCode = runCode;
window.resetCode = resetCode;
window.saveCode = saveCode;