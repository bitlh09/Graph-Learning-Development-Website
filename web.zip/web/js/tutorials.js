// 教程交互功能模块

// 教程页：最小代码运行按钮（展示示例输出）
function runGCNCode() {
    var out = document.getElementById('gcn-output');
    if (out) out.classList.remove('hidden');
}

function runGATCode() {
    var out = document.getElementById('gat-output');
    if (out) out.classList.remove('hidden');
}

function runGraphSAGECode() {
    var out = document.getElementById('graphsage-output');
    if (out) out.classList.remove('hidden');
}

// 微博问答检查
function checkWeiboAnswer() {
    var selected = document.querySelector('input[name="weibo-graph"]:checked');
    if (selected && selected.id === 'weibo-directed') {
        alert('正确！微博的关注关系是有向图，因为关注是单向的（A关注B，但B不一定关注A）。');
    } else if (selected) {
        alert('不完全正确。微博的关注关系主要是有向图，因为关注通常是单向的。');
    } else {
        alert('请先选择一个答案！');
    }
}

// 切换执行模式
function switchExecMode(mode) {
    practiceState.execMode = mode;
    var consoleEl = document.getElementById('console-output');
    if (mode === 'pyodide' && !practiceState.pyodideReady) {
        if (consoleEl) consoleEl.textContent = 'Pyodide 尚未就绪，正在加载...';
        initPyodideOnce();
    } else {
        if (consoleEl) consoleEl.textContent = '已切换执行模式：' + (mode === 'pyodide' ? 'Pyodide' : '前端模拟');
    }
}

// 创建交互式图演示（首页用）
function initHomeGraphDemo() {
    // 在页面加载完成后初始化首页的图演示
    setTimeout(function() {
        createGraphDemo('graph-demo');
    }, 500);
}

// 创建社交网络图演示
function initSocialGraphDemo() {
    setTimeout(function() {
        createSocialNetworkDemo('social-graph-demo');
    }, 500);
}

function createSocialNetworkDemo(containerId) {
    var container = document.getElementById(containerId);
    if (!container || !window.d3) return;
    
    container.innerHTML = '';
    var width = container.clientWidth || 300;
    var height = 200;
    var svg = d3.select(container).append('svg').attr('width', width).attr('height', height);
    
    var nodes = [
        {id: 0, name: '小明', age: 20, profession: '学生'},
        {id: 1, name: '小红', age: 25, profession: '设计师'},
        {id: 2, name: '小刚', age: 28, profession: '工程师'},
        {id: 3, name: '小丽', age: 30, profession: '教师'},
        {id: 4, name: '小强', age: 26, profession: '医生'}
    ];
    
    var links = [
        {source: 0, target: 1, relationship: '同学', strength: 0.8},
        {source: 1, target: 2, relationship: '同事', strength: 0.6},
        {source: 2, target: 3, relationship: '朋友', strength: 0.9},
        {source: 3, target: 4, relationship: '邻居', strength: 0.4},
        {source: 0, target: 4, relationship: '朋友', strength: 0.7}
    ];
    
    var simulation = d3.forceSimulation(nodes)
        .force('link', d3.forceLink(links).id(function(d) { return d.id; }).distance(60))
        .force('charge', d3.forceManyBody().strength(-200))
        .force('center', d3.forceCenter(width / 2, height / 2));

    var link = svg.append('g').selectAll('line').data(links).enter().append('line')
        .attr('stroke', '#999')
        .attr('stroke-width', function(d) { return d.strength * 3; })
        .attr('stroke-opacity', 0.6);

    var node = svg.append('g').selectAll('circle').data(nodes).enter().append('circle')
        .attr('r', 12)
        .attr('fill', function(d) { 
            var colors = {'学生': '#3b82f6', '设计师': '#ef4444', '工程师': '#10b981', '教师': '#f59e0b', '医生': '#8b5cf6'};
            return colors[d.profession] || '#6b7280';
        })
        .style('cursor', 'pointer')
        .on('click', function(event, d) {
            var info = '用户信息：\n姓名：' + d.name + '\n年龄：' + d.age + '\n职业：' + d.profession;
            alert(info);
        })
        .call(d3.drag()
            .on('start', function(event, d) { 
                if (!event.active) simulation.alphaTarget(0.3).restart(); 
                d.fx = d.x; d.fy = d.y; 
            })
            .on('drag', function(event, d) { 
                d.fx = event.x; d.fy = event.y; 
            })
            .on('end', function(event, d) { 
                if (!event.active) simulation.alphaTarget(0); 
                d.fx = null; d.fy = null; 
            })
        );
    
    var labels = svg.append('g').selectAll('text').data(nodes).enter().append('text')
        .text(function(d) { return d.name; })
        .attr('text-anchor', 'middle')
        .attr('dy', '.35em')
        .attr('font-size', '10px')
        .attr('fill', 'white')
        .attr('font-weight', 'bold');

    simulation.on('tick', function() {
        link.attr('x1', function(d) { return d.source.x; })
            .attr('y1', function(d) { return d.source.y; })
            .attr('x2', function(d) { return d.target.x; })
            .attr('y2', function(d) { return d.target.y; });
        node.attr('cx', function(d) { return d.x; }).attr('cy', function(d) { return d.y; });
        labels.attr('x', function(d) { return d.x; }).attr('y', function(d) { return d.y; });
    });
}

// 创建消息传递演示
function initMessagePassingDemo() {
    setTimeout(function() {
        createMessagePassingDemo('message-passing-demo');
    }, 500);
}

function createMessagePassingDemo(containerId) {
    var container = document.getElementById(containerId);
    if (!container || !window.d3) return;
    
    container.innerHTML = '';
    var width = container.clientWidth || 300;
    var height = 200;
    var svg = d3.select(container).append('svg').attr('width', width).attr('height', height);
    
    // 创建一个简单的5节点图
    var nodes = [
        {id: 0, x: width/2, y: height/2, features: [1, 0, 0], messages: []},
        {id: 1, x: width/2 - 60, y: height/2 - 40, features: [0, 1, 0], messages: []},
        {id: 2, x: width/2 + 60, y: height/2 - 40, features: [0, 0, 1], messages: []},
        {id: 3, x: width/2 - 60, y: height/2 + 40, features: [1, 1, 0], messages: []},
        {id: 4, x: width/2 + 60, y: height/2 + 40, features: [0, 1, 1], messages: []}
    ];
    
    var links = [
        {source: 0, target: 1}, {source: 0, target: 2}, 
        {source: 0, target: 3}, {source: 0, target: 4}
    ];
    
    // 绘制边
    var link = svg.selectAll('line').data(links).enter().append('line')
        .attr('x1', function(d) { return nodes[d.source].x; })
        .attr('y1', function(d) { return nodes[d.source].y; })
        .attr('x2', function(d) { return nodes[d.target].x; })
        .attr('y2', function(d) { return nodes[d.target].y; })
        .attr('stroke', '#cbd5e1')
        .attr('stroke-width', 2);
    
    // 绘制节点
    var node = svg.selectAll('circle').data(nodes).enter().append('circle')
        .attr('cx', function(d) { return d.x; })
        .attr('cy', function(d) { return d.y; })
        .attr('r', 15)
        .attr('fill', '#3b82f6')
        .attr('stroke', '#1e40af')
        .attr('stroke-width', 2)
        .style('cursor', 'pointer')
        .on('click', function(event, d) {
            var info = '节点 ' + d.id + '\n特征向量：[' + d.features.join(', ') + ']';
            alert(info);
        });
    
    // 添加节点标签
    var labels = svg.selectAll('text').data(nodes).enter().append('text')
        .attr('x', function(d) { return d.x; })
        .attr('y', function(d) { return d.y; })
        .attr('text-anchor', 'middle')
        .attr('dy', '.35em')
        .attr('font-size', '12px')
        .attr('fill', 'white')
        .attr('font-weight', 'bold')
        .text(function(d) { return d.id; });
}

// 页面加载时初始化演示
document.addEventListener('DOMContentLoaded', function() {
    // 延迟初始化，确保DOM完全加载
    setTimeout(function() {
        if (document.getElementById('graph-demo')) {
            initHomeGraphDemo();
        }
        if (document.getElementById('social-graph-demo')) {
            initSocialGraphDemo();
        }
        if (document.getElementById('message-passing-demo')) {
            initMessagePassingDemo();
        }
    }, 1000);
});

// 导出函数
window.runGCNCode = runGCNCode;
window.runGATCode = runGATCode;
window.runGraphSAGECode = runGraphSAGECode;
window.checkWeiboAnswer = checkWeiboAnswer;
window.switchExecMode = switchExecMode;
window.initHomeGraphDemo = initHomeGraphDemo;
window.initSocialGraphDemo = initSocialGraphDemo;
window.initMessagePassingDemo = initMessagePassingDemo;